from scytheautoupdate import check_for_updates
